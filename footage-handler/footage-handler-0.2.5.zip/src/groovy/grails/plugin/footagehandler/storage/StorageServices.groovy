package grails.plugin.footagehandler.storage

/**
 * Defines all supported storage services.
 */
public enum StorageServices {
    AMAZON_S3,
    RACKSPACE_CLOUDFILES
}