package grails.plugin.footagehandler.storage


interface RemoveBehavior {

    def execute(String key)

}
