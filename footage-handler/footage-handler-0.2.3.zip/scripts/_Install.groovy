//
// This script is executed by Grails after plugin was installed to project.
// This script is a Gant script so you can use all special variables provided
// by Gant (such as 'baseDir' which points on project base dir). You can
// use 'ant' to access a global instance of AntBuilder
//
// For example you can create directory under project tree:
//
//    ant.mkdir(dir:"${basedir}/grails-app/jobs")
//

def insertInstance = new InsertText("$basedir/grails-app",
        "conf/Config.groovy",
        "grails.plugins.megusta.footage.handler.extensions.default")

def input = """
        //added by the footage-handler plugin'
        //feel free to implement unlimited different restrictions
        //replace the value "default" in the field extensions
        environments {
            production {

            }
            development {
                grails.plugins.megusta.footage.handler.storage.default = "s3" //local or s3
                grails.plugins.megusta.footage.handler.required.default = true
                grails.plugins.megusta.footage.handler.subdirectory.default =  "images/"
                grails.plugins.megusta.footage.handler.extensions.default = ["jpg", "png", "img"]
                grails.plugins.megusta.footage.handler.maxFileSize.default = 524288 * 2 // in bytes
                grails.plugins.megusta.footage.handler.bucket.default = 'megchat'
                grails.plugins.megusta.footage.handler.bucketLink.default = 'https://s3-eu-west-1.amazonaws.com/'

                grails.plugin.aws.accessKey = ''
                grails.plugin.aws.secretKey = ''
                grails.plugin.aws.bucket    = 'megchat'
                grails.plugin.aws.bucketLink= "https://s3-eu-west-1.amazonaws.com/"
            }
            test { }
        } 
"""
insertInstance.putTextOnce(input)


class InsertText {
    def appDir
    def fileString
    def identifier

    InsertText(def appDirCon, def fileStringCon, def identifierCon) {
        appDir = appDirCon
        fileString = fileStringCon
        identifier = identifierCon
    }

    def putTextOnce(def input) {
        if (!alreadyInstalled()) {
            getFile().withWriterAppend {
                it.writeLine input
            }
        }
    }

    def alreadyInstalled() {
        def result = 0
        getFile().eachLine({
            if (it.findAll(identifier).size() == 1) {
                result = result + 1
            }
            if (it.findAll(identifier).size() > 1) {
                throw new Exception("String.not.unique")
            }
        })
        if (result > 1) {
            throw new Exception("String.not.unique")
        } else if (result == 1) {
            return true
        } else if (result == 0) {
            return false
        }
    }

    def getFile() {
        new File(appDir, fileString)
    }
}