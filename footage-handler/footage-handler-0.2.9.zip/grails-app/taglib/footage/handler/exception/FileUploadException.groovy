package footage.handler.exception

class FileUploadException extends RuntimeException {

    public FileUploadException(Throwable t) {
        super(t)
    }

}
